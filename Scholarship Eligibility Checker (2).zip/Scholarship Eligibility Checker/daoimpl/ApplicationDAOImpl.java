package com.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.bean.Application;
import com.bean.Student;
import com.bean.Scholarship;
import com.dao.ApplicationDAO;
import com.util.ConnectionFactory;

public class ApplicationDAOImpl implements ApplicationDAO {

	@Override
	public void applyScholarship(Application application) {
		try {
			Connection con = ConnectionFactory.getConnection();

			// Get student details
			StudentDAOImpl studentDAO = new StudentDAOImpl();
			Student student = studentDAO.getStudentById(application.getStudentId());

			// Get scholarship details
			ScholarshipDAOImpl scholarshipDAO = new ScholarshipDAOImpl();
			Scholarship scholarship = scholarshipDAO.getScholarshipById(application.getScholarshipId());

			String status;

			if (student.getMarks() >= scholarship.getMinMarks() && student.getIncome() <= scholarship.getMaxIncome()) {

				status = "APPROVED";
			} else {
				status = "REJECTED";
			}

			String sql = "INSERT INTO application(student_id,scholarship_id,status) VALUES(?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, application.getStudentId());
			ps.setInt(2, application.getScholarshipId());
			ps.setString(3, status);

			ps.executeUpdate();
			System.out.println("Application submitted! Status: " + status);

			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}