package com.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.bean.User;
import com.dao.UserDAO;
import com.util.ConnectionFactory;

public class UserDAOImpl implements UserDAO {

	public void addUser(User user) {
		try {
			Connection con = ConnectionFactory.getConnection();
			String sql = "INSERT INTO users(username,password,role) VALUES(?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getRole());
			ps.executeUpdate();
			System.out.println("User added successfully!");
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}