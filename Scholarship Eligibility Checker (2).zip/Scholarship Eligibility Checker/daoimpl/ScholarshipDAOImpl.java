package com.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.bean.Scholarship;
import com.dao.ScholarshipDAO;
import com.util.ConnectionFactory;

public class ScholarshipDAOImpl implements ScholarshipDAO {

	@Override
	public void addScholarship(Scholarship scholarship) {
		try {
			Connection con = ConnectionFactory.getConnection();
			String sql = "INSERT INTO scholarship(name,min_marks,max_income,amount) VALUES(?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, scholarship.getName());
			ps.setDouble(2, scholarship.getMinMarks());
			ps.setDouble(3, scholarship.getMaxIncome());
			ps.setDouble(4, scholarship.getAmount());
			ps.executeUpdate();
			System.out.println("Scholarship added successfully!");
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public Scholarship getScholarshipById(int id) {
		Scholarship scholarship = null;
		try {
			Connection con = ConnectionFactory.getConnection();
			String sql = "SELECT * FROM scholarship WHERE scholarship_id=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				scholarship = new Scholarship();
				scholarship.setScholarshipId(rs.getInt("scholarship_id"));
				scholarship.setName(rs.getString("name"));
				scholarship.setMinMarks(rs.getDouble("min_marks"));
				scholarship.setMaxIncome(rs.getDouble("max_income"));
				scholarship.setAmount(rs.getDouble("amount"));
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return scholarship;
	}
}