package com.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.bean.Student;
import com.dao.StudentDAO;
import com.util.ConnectionFactory;

public class StudentDAOImpl implements StudentDAO {

	public void addStudent(Student student) {
		try {
			Connection con = ConnectionFactory.getConnection();
			String sql = "INSERT INTO student(name,income,marks,user_id) VALUES(?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, student.getName());
			ps.setDouble(2, student.getIncome());
			ps.setDouble(3, student.getMarks());
			ps.setInt(4, student.getUserId());
			ps.executeUpdate();
			System.out.println("Student added successfully!");
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Student getStudentById(int id) {
		Student student = null;
		try {
			Connection con = ConnectionFactory.getConnection();
			String sql = "SELECT * FROM student WHERE student_id=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				student = new Student();
				student.setStudentId(rs.getInt("student_id"));
				student.setName(rs.getString("name"));
				student.setIncome(rs.getDouble("income"));
				student.setMarks(rs.getDouble("marks"));
				student.setUserId(rs.getInt("user_id"));
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return student;
	}
}