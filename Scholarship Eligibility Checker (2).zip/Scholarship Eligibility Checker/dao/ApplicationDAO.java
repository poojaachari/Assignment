package com.dao;

import com.bean.Application;

public interface ApplicationDAO {

	void applyScholarship(Application application);

}