package com.dao;

import com.bean.User;

public interface UserDAO {
	void addUser(User user);
}
