package com.dao;

import com.bean.Student;

public interface StudentDAO {
	void addStudent(Student student);

	Student getStudentById(int id);
}
