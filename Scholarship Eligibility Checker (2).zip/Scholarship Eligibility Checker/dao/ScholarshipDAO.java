package com.dao;

import com.bean.Scholarship;

public interface ScholarshipDAO {

	void addScholarship(Scholarship scholarship);

	Scholarship getScholarshipById(int id);

}