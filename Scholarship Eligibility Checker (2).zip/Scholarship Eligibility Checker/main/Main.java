package com.main;

import java.util.Scanner;

import com.bean.*;
import com.dao.impl.*;

public class MainApp {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		UserDAOImpl userDAO = new UserDAOImpl();
		StudentDAOImpl studentDAO = new StudentDAOImpl();
		ScholarshipDAOImpl scholarshipDAO = new ScholarshipDAOImpl();
		ApplicationDAOImpl applicationDAO = new ApplicationDAOImpl();

		while (true) {

			System.out.println("\n===== Scholarship Eligibility Checker =====");
			System.out.println("1. Add User");
			System.out.println("2. Add Student");
			System.out.println("3. Add Scholarship");
			System.out.println("4. Apply for Scholarship");
			System.out.println("5. Exit");
			System.out.print("Enter choice: ");

			int choice = sc.nextInt();
			sc.nextLine();

			switch (choice) {

			case 1:
				User user = new User();
				System.out.print("Enter User ID: ");
				user.setUserId(sc.nextInt());
				System.out.print("Enter Username: ");
				user.setUsername(sc.nextLine());
				sc.nextLine();
				System.out.print("Enter Password: ");
				user.setPassword(sc.nextLine());
				System.out.print("Enter Role: ");
				user.setRole(sc.nextLine());
				userDAO.addUser(user);
				break;

			case 2:
				Student student = new Student();
				System.out.print("Enter User ID: ");
				student.setUserId(sc.nextInt());
				System.out.print("Enter Student ID: ");
				student.setStudentId(sc.nextInt());
				sc.nextLine();
				System.out.print("Enter Name: ");
				student.setName(sc.nextLine());
				System.out.print("Enter Marks: ");
				student.setMarks(sc.nextDouble());
				System.out.print("Enter Family Income: ");
				student.setIncome(sc.nextDouble());
				studentDAO.addStudent(student);
				break;

			case 3:
				Scholarship scholarship = new Scholarship();
				System.out.print("Enter scholarship ID: ");
				scholarship.setScholarshipId(sc.nextInt());
				System.out.print("Enter Scholarship Name: ");
				scholarship.setName(sc.nextLine());
				sc.nextLine();
				System.out.print("Enter Minimum Marks Required: ");
				scholarship.setMinMarks(sc.nextDouble());
				System.out.print("Enter Maximum Income Allowed: ");
				scholarship.setMaxIncome(sc.nextDouble());
				System.out.print("Enter Scholarship Amount: ");
				scholarship.setAmount(sc.nextDouble());
				scholarshipDAO.addScholarship(scholarship);
				break;

			case 4:
				Application application = new Application();
				System.out.print("Enter Application ID: ");
				application.setApplicationId(sc.nextInt());
				System.out.print("Enter Student ID: ");
				application.setStudentId(sc.nextInt());
				System.out.print("Enter Scholarship ID: ");
				application.setScholarshipId(sc.nextInt());
				applicationDAO.applyScholarship(application);
				break;

			case 5:
				System.out.println("Thank You!");
				sc.close();
				System.exit(0);
				break;

			default:
				System.out.println("Invalid Choice!");
			}
		}
	}
}