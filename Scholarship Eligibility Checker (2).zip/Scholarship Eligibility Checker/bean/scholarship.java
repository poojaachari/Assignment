package com.bean;

public class Scholarship {
	private int scholarshipId;
	private String name;
	private double minMarks;
	private double maxIncome;
	private double amount;

	public int getScholarshipId() {
		return scholarshipId;
	}

	public void setScholarshipId(int scholarshipId) {
		this.scholarshipId = scholarshipId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getMinMarks() {
		return minMarks;
	}

	public void setMinMarks(double minMarks) {
		this.minMarks = minMarks;
	}

	public double getMaxIncome() {
		return maxIncome;
	}

	public void setMaxIncome(double maxIncome) {
		this.maxIncome = maxIncome;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
}
