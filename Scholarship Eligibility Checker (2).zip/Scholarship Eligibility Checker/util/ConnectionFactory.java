package com.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionFactory {
	public static Connection getConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			return DriverManager.getConnection("jdbc:mysql://localhost:3306/scholarshipdb", "root", "Achari@2004Pooja");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
